const express = require('express');
const router = express.Router();

const { getUser, deleteUser, viewUser } = require('../controllers/userController')
const { verifyToken } = require('../middleware/verifyToken')

router.get('/getUser', getUser);
router.delete('/deleteUser/:id', deleteUser);
router.get('/viewUser/:id', viewUser);
// router.post('/logout', verifyToken, logout);

module.exports = router;