const express = require('express');
const router = express.Router();

const { signup, login, sendEmail, resetPassword, verifyOTP, logout } = require('../controllers/authController')
const { verifyToken } = require('../middleware/verifyToken')

//as User

router.post('/signup', signup);
router.post('/login', login);
router.post('/send-email', sendEmail)
router.post("/resetPassword", resetPassword);
router.post("/verifyOTP", verifyOTP);
router.post('/logout', verifyToken, logout);


module.exports = router;