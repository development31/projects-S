const express = require('express');
const router = express.Router();

const { getVendor, deleteVendor, viewVendor } = require('../controllers/vendorController')
const { verifyToken } = require('../middleware/verifyToken')

router.get('/getVendor', getVendor);
router.delete('/deleteVendor/:id', deleteVendor);
router.get('/viewVendor/:id', viewVendor);

// router.post('/logout', verifyToken, logout);

module.exports = router;