const express = require('express');
const router = express.Router();
const { createShopDetails, getAllShopDetails, getShopDetailsById, deleteShopDetails ,upload} = require('../controllers/shopDetailsController');

// Multer middleware for handling file uploads
// const uploaded = upload;

// POST request - Create new shop details with image upload
router.post('/add', upload.single('shopLogo'), createShopDetails);
router.get('/getAll', getAllShopDetails);
router.get('/:id', getShopDetailsById);
router.delete('/shopDetails/:id', deleteShopDetails);

module.exports = router;
