const mongoose = require('mongoose');

const ShopDetailsSchema = new mongoose.Schema({
  shopName: {
    type: String,
    required: true,
  },
  shopDescription: {
    type: String,
    required: true,
  },
  ownerName: {
    type: String,
    required: true,
  },
  ownerEmail: {
    type: String,
    required: true,
  },
  contactNumber: {
    type: String,
  },
  availableFrom: {
    type: String,
  },
  availableFromPeriod: {
    type: String,
    enum: ['AM', 'PM'],
    default: 'AM',
  },
  availableTo: {
    type: String,
  },
  availableToPeriod: {
    type: String,
    enum: ['AM', 'PM'],
    default: 'PM',
  },
  shopLogo: {
    type: String, // Assuming storing the path to the image
  },
  address: {
    type: String,
  },
});

module.exports = mongoose.model('ShopDetails', ShopDetailsSchema);
