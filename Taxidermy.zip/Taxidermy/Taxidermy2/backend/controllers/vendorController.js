const Vendor = require('../models/userModel');
const createError = require('../middleware/error')
const createSuccess = require('../middleware/success')

const getVendor = async (req, res) => {
  try {
    const result = await Vendor.find({ role: "vendor" });
    res.json({
      msg: 'get all vendor',
      status: 200,
      data: result
    })
  } catch (error) {
    res.status(500).send("error");
  }
}

const deleteVendor = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await Vendor.findByIdAndDelete(id);
    res.json({
      msg: 'vendor deleted....!',
      status: 200,
    })
  } catch (error) {
    res.status(500).send("error");
  }
}

const viewVendor = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await Vendor.findById(id);
    res.json({
      msg: 'get all user',
      status: 200,
      data: result
    })
  } catch (error) {
    res.status(500).send("error");
  }
}

module.exports = { getVendor, deleteVendor, viewVendor }
