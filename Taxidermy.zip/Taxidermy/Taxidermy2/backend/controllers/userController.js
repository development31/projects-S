const User = require('../models/userModel');
const createError = require('../middleware/error')
const createSuccess = require('../middleware/success')

const getUser = async (req, res) => {
  try {
    const result = await User.find({ role: "user" });
    res.json({
      msg: 'get all user',
      status: 200,
      data: result
    })
  } catch (error) {
    res.status(500).send("error");
  }
}


const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await User.findByIdAndDelete(id);
    res.json({
      msg: 'user deleted....!',
      status: 200,
    })
  } catch (error) {
    res.status(500).send("error");
  }
}


const viewUser = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await User.findById(id);
    res.json({
      msg: 'get all user',
      status: 200,
      data: result
    })
  } catch (error) {
    res.status(500).send("error");
  }
}


module.exports = { getUser, deleteUser, viewUser }