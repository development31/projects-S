const ShopDetails = require('../models/shopDetailsModel');
const multer = require('multer');
const path = require('path');

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './uploads/'); // Destination folder where files will be stored
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext); // Unique filename with timestamp
  },
});

const upload = multer({ storage: storage });

// Create new shop details with image upload
const createShopDetails = async (req, res, next) => {
  try {
    const {
      shopName,
      shopDescription,
      ownerName,
      ownerEmail,
      contactNumber,
      availableFrom,
      availableFromPeriod,
      availableTo,
      availableToPeriod,
      address,
    } = req.body;

    // File upload handling
    const shopLogo = req.file ? req.file.path : null;

    const newShopDetails = new ShopDetails({
      shopName,
      shopDescription,
      ownerName,
      ownerEmail,
      contactNumber,
      availableFrom,
      availableFromPeriod,
      availableTo,
      availableToPeriod,
      shopLogo,
      address,
    });

    await newShopDetails.save();

    res.status(201).json({ message: 'Shop details created successfully', shopDetails: newShopDetails });
  } catch (error) {
    console.error('Error creating shop details:', error);
    res.status(500).json({ message: 'Failed to create shop details' });
  }
};

const getAllShopDetails = async (req, res, next) => {
    try {
      const shopDetails = await ShopDetails.find();
      res.status(200).json(shopDetails);
    } catch (error) {
      console.error('Error fetching shop details:', error);
      res.status(500).json({ message: 'Failed to fetch shop details' });
    }
  };

  const getShopDetailsById = async (req, res, next) => {
    const shopId = req.params.id; // Get shop ID from request parameters
  
    try {
      const shopDetails = await ShopDetails.findById(shopId);
  
      if (!shopDetails) {
        return res.status(404).json({ message: 'Shop details not found' });
      }
  
      res.status(200).json(shopDetails);
    } catch (error) {
      console.error('Error fetching shop details by ID:', error);
      res.status(500).json({ message: 'Failed to fetch shop details by ID' });
    }
  };

  const deleteShopDetails = async (req, res) => {
    try {
      const { id } = req.params;
      console.log(id)
      const result = await ShopDetails.findByIdAndDelete(id);
      res.json({
        msg: 'user deleted....!',
        status: 200,
      })
    } catch (error) {
      res.status(500).send("error");
    }
  }

module.exports = {
  createShopDetails,
  getAllShopDetails,
  getShopDetailsById,
  deleteShopDetails,
  upload, // Exporting multer instance for use in routes
};
