const User = require('../models/userModel');
const createError = require('../middleware/error')
const createSuccess = require('../middleware/success')
const jwt = require('jsonwebtoken')
const nodemailer = require('nodemailer')
const bcrypt = require('bcrypt');


const signup = async (req, res) => {
  try {
    const { name, email, password, mobileNumber, role } = req.body;
    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({ message: 'User already exists' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const value = new User({
      name: name,
      email: email,
      password: hashedPassword,
      contactNumber: mobileNumber,
      role: role
    })

    await value.save();

    res.json({
      msg: 'signed up successfully',
      status: 200,
      success: true
    })

  } catch (error) {
    res.status(500).send("error");
  }
}

const login = async (req, res) => {

  try {
    const { email, password, role } = req.body;
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign({ userId: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.cookie("access_token", token, { httpOnly: true })
      .status(200)
      .json({
        status: 200,
        message: "Login Success",
        token,
        data: user
      });
  } catch (error) {
    res.status(500).json({ msg: "Server error", error: error.message });
  }
}

//sendresetmail
const sendEmail = async (req, res) => {
  const email = req.body.email;
  try {

    if (!email) {
      return res.status(400).json({ message: "Invalid email format" });
    }

    let user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({ message: "Invalid Email" });
    }

    const otp = Math.floor(1000 + Math.random() * 9000).toString();
    user.otp = otp;
    user.otpExpiration = Date.now() + 15 * 60 * 1000;
    await user.save();

    const mailTransporter = nodemailer.createTransport({
      service: "GMAIL",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    const mailDetails = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Password Reset OTP",
      html: `<p>Your OTP for password reset is: <strong>${otp}</strong></p><p>This OTP is valid for 15 minutes.</p>
      `
    };

    mailTransporter.sendMail(mailDetails);
    res.json({
      msg: "OTP sent to your mail",
      status: 200,
      data: mailDetails
    })
  } catch (error) {
    res.status(500).json({ msg: "Server error", error: error.message });
  }
};

const verifyOTP = async (req, res) => {
  const { otp } = req.body;
  try {

    let user = await User.findOne({ otp, otpExpiration: { $gt: Date.now() } });
    if (!user) {
      res.json({
        msg: "Invalid or expired OTP",
        status: 400
      })
    }

    user.otp = undefined;
    user.otpExpiration = undefined;
    await user.save();

    const token = jwt.sign({ email: user.email }, process.env.JWT_SECRET, { expiresIn: '15m' });
    res.json({
      msg: "OTP Verified successfully!",
      status: 200,
      token: token
    })
  } catch (error) {
    res.json({
      msg: "Internal Server Error",
      status: 500
    })
  }
};

// Reset Password
const resetPassword = async (req, res) => {
  const { token, newPassword } = req.body;
  try {
    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);
    const userEmail = decodedToken.email;

    let user = await User.findOne({ email: userEmail });
    if (!user) {
      res.json({
        msg: "Invalid token",
        status: 400
      })
    }
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(newPassword, saltRounds);

    user.password = hashedPassword;
    await user.save();
    res.json({
      msg: "Password reset Successfully!",
      status: 200
    })
  } catch (error) {
    res.json({
      msg: "Internal Server Error",
      status: 500
    })
  }
};

// in logout reset the token
const logout = async (req, res) => {
  try {
    res.clearCookie('token');
    res.json({
      msg: "Logged out Succeessfully!",
      status: 200
    })
  } catch (error) {
    res.json({
      msg: "error",
      status: 500
    })
  }
};

module.exports = { signup, login, sendEmail, verifyOTP, resetPassword, logout }