import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  CCard,
  CCardHeader,
  CButton,
  CListGroup,
  CListGroupItem,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalFooter,
  CModalBody,
  CForm,
  CFormInput,
  CDropdown,
  CDropdownToggle,
  CDropdownMenu,
  CDropdownItem,
  CTable,
  CTableHead,
  CTableRow,
  CTableHeaderCell,
  CTableBody,
  CTableDataCell,
  CAlert,
  CCardBody,
  CCardText,
  CPagination,
  CPaginationItem,
  CFormLabel,
  CFormSelect,
} from "@coreui/react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEdit, faTrash, faEye } from "@fortawesome/free-solid-svg-icons";

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [selectedVendor, setSelectedVendor] = useState(null);
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');
  const [newStatus, setNewStatus] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://localhost:3002/api/getAll");
      setUsers(response.data);
      setLoading(false);
    } catch (error) {
      setError("Error fetching users");
      console.error("Error fetching users:", error);
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3002/api/shopDetails/${id}`);
      setUsers(users.filter((user) => user._id !== id));
    } catch (error) {
      setError("Error deleting user");
      console.error("Error deleting user:", error);
    }
  };

  const handleViewOrder = (order) => {
    setSelectedVendor(order);
    setNewStatus(order.status); // Initialize status in modal
    setVisible(true);
  };

  const handleStatusChange = (event) => {
    setNewStatus(event.target.value);
  };

  const handleUpdateStatus = async (id) => {
    if (newStatus === '') {
      console.error("Status cannot be empty");
      return;
    }
    try {
      await axios.get(`http://localhost:3002/api/${selectedVendor._id}`, { status: newStatus });
      
      setUsers(users.map(user =>
        user._id === selectedVendor._id ? { ...user, status: newStatus } : user
      ));

      setVisible(false);
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleFilterChange = (status) => {
    setFilter(status);
  };

  const filteredUsers = filter === 'ALL'
    ? users
    : users.filter(user => user.status === filter);

  const currentFilterLabel = filter !== 'ALL' ? filter : 'Filter by Status';

  return (
    <>
      {error && <CAlert color="danger">{error}</CAlert>}
      <CCard>
        <CCardHeader className="d-flex justify-content-between align-items-center">
          <h3>Manage Vendors</h3>
          <div className="d-flex" style={{ marginLeft: 'auto' }}>
            <CForm style={{ width: '12rem', marginRight: '1rem' }}>
              <CFormInput
                type="text"
                placeholder="Search by Name"
                // Implement search functionality if needed
              />
            </CForm>

            <CDropdown style={{ width: '12rem' }}>
              <CDropdownToggle color="secondary">
                {currentFilterLabel}
              </CDropdownToggle>
              <CDropdownMenu style={{ width: '12rem', textAlign: 'center' }}>
                <CDropdownItem onClick={() => handleFilterChange('ALL')}>ALL</CDropdownItem>
                <CDropdownItem onClick={() => handleFilterChange('APPROVE')}>APPROVE</CDropdownItem>
                <CDropdownItem onClick={() => handleFilterChange('REJECT')}>REJECT</CDropdownItem>
                <CDropdownItem onClick={() => handleFilterChange('PENDING')}>PENDING</CDropdownItem>
              </CDropdownMenu>
            </CDropdown>

          </div>
        </CCardHeader>
        <CCardBody>
          <CCardText>
            <CTable responsive striped hover bordered>
              <CTableHead color="dark">
                <CTableRow>
                  <CTableHeaderCell scope="col" style={{ textAlign: "center" }}>#</CTableHeaderCell>
                  <CTableHeaderCell scope="col" style={{ textAlign: "center" }}>Owner Name</CTableHeaderCell>
                  <CTableHeaderCell scope="col" style={{ textAlign: "center" }}>Owner Email</CTableHeaderCell>
                  <CTableHeaderCell scope="col" style={{ textAlign: "center" }}>Contact Number</CTableHeaderCell>
                  <CTableHeaderCell scope="col" style={{ textAlign: "center" }}>Status</CTableHeaderCell>
                  <CTableHeaderCell scope="col" style={{ textAlign: "center" }}>Action</CTableHeaderCell>
                </CTableRow>
              </CTableHead>
              <CTableBody>
                {loading ? (
                  <CTableRow>
                    <CTableDataCell colSpan="6">Loading...</CTableDataCell>
                  </CTableRow>
                ) : (
                  filteredUsers.map((user, index) => (
                    <CTableRow key={user._id}>
                      <CTableHeaderCell scope="row" style={{ textAlign: "center" }}>{index + 1}</CTableHeaderCell>
                      <CTableDataCell style={{ textAlign: "center" }}>
                        {user.ownerName || "null"}
                      </CTableDataCell>
                      <CTableDataCell style={{ textAlign: "center" }}>
                        {user.ownerEmail || "null"}
                      </CTableDataCell>
                      <CTableDataCell style={{ textAlign: "center" }}>
                        {user.contactNumber || "null"}
                      </CTableDataCell>
                      <CTableDataCell style={{ textAlign: "center" }}>
                        {user.status || "null"}
                      </CTableDataCell>
                      <CTableDataCell style={{ textAlign: "center" }}>
                        <CButton size="sm" onClick={() => handleViewOrder(user)}>
                          <FontAwesomeIcon icon={faEye} style={{ color: "grey", cursor: 'pointer', marginRight: '5px' }} />
                        </CButton>
                        <CButton size="sm" onClick={() => handleDelete(user._id)}>
                          <FontAwesomeIcon
                            icon={faTrash}
                            style={{ color: "#fd2b2b" }}
                          />
                        </CButton>
                      </CTableDataCell>
                    </CTableRow>
                  ))
                )}
              </CTableBody>
            </CTable>
          </CCardText>
          <CPagination align="center" aria-label="Page navigation example">
            <CPaginationItem disabled aria-label="Previous">
              <span aria-hidden="true">&laquo;</span>
            </CPaginationItem>
            <CPaginationItem active>1</CPaginationItem>
            <CPaginationItem>2</CPaginationItem>
            <CPaginationItem>3</CPaginationItem>
            <CPaginationItem aria-label="Next">
              <span aria-hidden="true">&raquo;</span>
            </CPaginationItem>
          </CPagination>
        </CCardBody>
      </CCard>

      <CModal visible={visible} onClose={() => setVisible(false)}>
        <CModalHeader onClose={() => setVisible(false)}>
          <CModalTitle>Vendor Details</CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CListGroup>
            <CListGroupItem><strong>Shop Name: </strong> {selectedVendor?.shopName}</CListGroupItem>
            <CListGroupItem><strong>Shop Description: </strong>{selectedVendor?.shopDescription}</CListGroupItem>
            <CListGroupItem><strong>Owner Name: </strong> {selectedVendor?.ownerName}</CListGroupItem>
            <CListGroupItem><strong>Owner Email: </strong> {selectedVendor?.ownerEmail}</CListGroupItem>
            <CListGroupItem><strong>Contact Number: </strong> {selectedVendor?.contactNumber}</CListGroupItem>
            <CListGroupItem><strong>Available From: </strong> {selectedVendor?.availableFrom} {selectedVendor?.availableFromPeriod} - {selectedVendor?.availableTo} {selectedVendor?.availableToPeriod}</CListGroupItem>
            <CListGroupItem><strong>Address: </strong> {selectedVendor?.address}</CListGroupItem>
            <CListGroupItem className="d-flex align-items-center">
              <CFormLabel><strong>Status: </strong></CFormLabel>
              <CFormSelect value={newStatus} onChange={handleStatusChange} style={{ width: '12rem', marginLeft: '1rem' }}>
                {/* <option>--select status--</option> */}
                <label>--select status--</label>
                <option value="APPROVE">APPROVE</option>
                <option value="REJECT">REJECT</option>
                <option value="PENDING">PENDING</option>
              </CFormSelect>
            </CListGroupItem>
          </CListGroup>
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setVisible(false)}>
            Close
          </CButton>
          <CButton color="primary" onClick={() => handleUpdateStatus(selectedVendor._id)}>
            Update Status
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  );
};

export default UserManagement;
