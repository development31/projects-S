const auth = require('../model/authModel');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const signup = async (req, res) => {
    
    try {
        const { name, email, password, contactNumber, role } = req.body;
        const existing=await auth.find({email});
        if(existing){
            return res.status(400).json({ message: 'User already exists' });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const value = new auth({
            name: name,
            email: email,
            password: hashedPassword,
            contactNumber: contactNumber,
            role: role
        })

        await value.save();

        res.send('signed up successfully')

    } catch (error) {
        res.send("error", error);
    }
}

const login = async (req, res) => {
    
    try {
        const { email, password, role } = req.body;
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const token = jwt.sign({ userId: user._id, role: user.role },  process.env.JWT_SECRET, { expiresIn: '1h' });
        res.cookie("access_token", token, { httpOnly: true })
        .status(200)
        .json({
            status: 200,
            message: "Login Success",
            token,
            data: user
        });
    } catch (error) {
        res.status(500).json({ msg: "Server error", error: error.message });
    }
}



// reset password => email shi hai but password yaad nhi
// number => otp
// email => mail 


module.exports = { signup, login };