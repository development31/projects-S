import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';

import {
  CButton,
  CCard,
  CCardBody,
  CCardGroup,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilLockLocked, cilUser } from '@coreui/icons'

const Login = () => {


  const navigateTo = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:4000/api/login', {
        email,
        password,
      });
      // console.log(response);
      setMessage(response.data.message);
      if (response.status === 200) {
        navigateTo('/dashboard');
      }
    } catch (error) {
      setMessage('Invalid login credentials!');
    }
  };




  return (
    <div className="bg-body-tertiary min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={8}>
            <CCardGroup>
              <CCard className="p-4" style={{ maxWidth: "65%", margin: "auto" }}>
                <CCardBody>
                  <CForm>
                    <h1 className="text-center">Login</h1>
                    <p className="text-body-secondary text-center">Sign In to your account</p>

                    <CInputGroup className="mb-3">
                      <CInputGroupText>
                        <CIcon icon={cilUser} />
                      </CInputGroupText>

                      <CFormInput
                        placeholder="Email"
                        autoComplete="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)} />


                    </CInputGroup>

                    <CInputGroup className="mb-4">
                      <CInputGroupText>
                        <CIcon icon={cilLockLocked} />
                      </CInputGroupText>
                      <CFormInput
                        type="password"
                        placeholder="Password"
                        autoComplete="current-password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                    </CInputGroup>

                    {/* <CRow >
                      <CCol xs={6} >

                        <CButton
                          color="primary"
                          // color="success"
                          variant="outline"
                          className="px-4"
                          onClick={handleLogin}
                        >
                          Login
                        </CButton>

                      </CCol>
                      <CCol xs={6} className="text-right">

                        <Link to='/forgot-password'>
                          <CButton color="link" className="px-0">
                            Forgot password?
                          </CButton>
                        </Link>

                      </CCol>
                    </CRow> */}

                    <CRow className="justify-content-center ">
                      <CCol xs="auto" className="text-center">
                        <CButton 
                          color="primary"
                          variant="outline"
                          className="px-4"
                          onClick={handleLogin}
                        >
                          Login
                        </CButton>
                      </CCol>
                    </CRow>

                    <CRow className="justify-content-center">
                      <CCol xs="auto" className="text-center">
                        <Link to='/forgot-password'>
                          <CButton color="link" className="px-0">
                            Forgot password?
                          </CButton>
                        </Link>
                      </CCol>
                    </CRow>


                    {message && <p className="text-danger mt-3 text-center" style={{ fontSize: '1.2rem', margin: "0rem"}}>{message}</p>}

                  </CForm>
                </CCardBody>
              </CCard>

              {/* <CCard className="text-white bg-primary py-5" style={{ width: '44%' }}>
                <CCardBody className="text-center">
                  <div>
                    <h2>Sign up</h2>
                    <p>
                    Please register if you don't have an account.
                    </p>
                    <Link to="/register">
                      <CButton color="primary" className="mt-3" active tabIndex={-1}>
                        Register Now!
                      </CButton>
                    </Link>
                  </div>
                </CCardBody>
              </CCard> */}

            </CCardGroup>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  )
}

export default Login
