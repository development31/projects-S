import React, {useState} from 'react'
import { CButton, CCard, CCardHeader, CCardBody, CModal, CModalBody, CModalFooter, CModalHeader, CModalContent, CModalTitle } from '@coreui/react'
import { DocsLink } from 'src/components'

const shop_owners = () => {
    const [visible, setVisible] = useState(false)
    return (
        <>
            <CCard className="mb-4">
                <CCardHeader style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    Shop Owners

                    <CButton style={{ marginLeft: 'auto' }} color="primary" onClick={() => setVisible(!visible)}>Launch demo modal</CButton>

                    <CModal
                        visible={visible}
                        onClose={() => setVisible(false)}
                        aria-labelledby="LiveDemoExampleLabel"
                    >
                        <CModalHeader>
                            <CModalTitle id="LiveDemoExampleLabel">Modal title</CModalTitle>
                        </CModalHeader>
                        <CModalBody>
                            <p>Woohoo, you're reading this text in a modal!</p>
                        </CModalBody>
                        <CModalFooter>
                            <CButton color="secondary" onClick={() => setVisible(false)}>
                                Close
                            </CButton>
                            <CButton color="primary">Save changes</CButton>
                        </CModalFooter>
                    </CModal>

                </CCardHeader>
                <CCardBody>

                </CCardBody>
            </CCard>
        </>

    )
}

export default shop_owners